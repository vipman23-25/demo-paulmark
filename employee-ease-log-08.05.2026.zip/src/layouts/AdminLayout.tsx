import { Outlet } from 'react-router-dom';
import { SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import { AdminSidebar } from '@/components/AdminSidebar';
import { useReminders } from '@/hooks/useReminders';

const AdminLayout = () => {
  useReminders();
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <div className="print:hidden">
            <AdminSidebar />
        </div>
        <div className="flex-1 flex flex-col">
          <header className="h-14 flex items-center border-b bg-card px-4 print:hidden">
            <SidebarTrigger className="mr-4" />
            <h1 className="text-lg font-semibold text-foreground">Personel Yönetim Sistemi</h1>
          </header>
          <main className="flex-1 p-6 print:p-0 print:m-0 overflow-auto">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default AdminLayout;
