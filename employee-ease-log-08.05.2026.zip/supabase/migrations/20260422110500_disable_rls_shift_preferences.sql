ALTER TABLE public.shift_preferences DISABLE ROW LEVEL SECURITY;
