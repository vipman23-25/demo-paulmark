import { useState, Fragment } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { FileDown, Calendar as CalIcon, Settings2, RefreshCw, Printer } from 'lucide-react';
import * as XLSX from 'xlsx';

const DAYS_TR = ['P.TESİ', 'SALI', 'ÇARŞ', 'PERŞ', 'CUMA', 'C.TESİ', 'PAZAR'];
const DAYS = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];

const formatDateTR = (dateStr: string) => {
    const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
    const d = new Date(dateStr);
    return `${d.getDate()} ${months[d.getMonth()]}`;
};

const getVirtualDept = (dept: string) => {
    if (!dept) return 'Tanımsız';
    const lowerDept = String(dept).toLocaleLowerCase('tr-TR');
    if (lowerDept.includes('kadın') || lowerDept.includes('çocuk') || lowerDept.includes('bayan')) {
        return 'Kadın & Çocuk Reyon';
    }
    return String(dept);
};

const ShiftEngineTab = () => {
  const queryClient = useQueryClient();
  const [selectedWeekStart, setSelectedWeekStart] = useState<string>('');
  const [generatedGrid, setGeneratedGrid] = useState<any[]>([]);
  const [isGenerated, setIsGenerated] = useState(false);
  const [showOnlyAssignedTasks, setShowOnlyAssignedTasks] = useState(true);

  // Fetch all necessary data for the engine
  const { data: engineContext, isLoading } = useQuery({
    queryKey: ['shift_engine_context'],
    queryFn: async () => {
        const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        
        const results = await Promise.all([
          supabase.from('personnel').select('*').eq('is_active', true),
          supabase.from('personnel_movements').select('*').gte('start_date', thirtyDaysAgo),
          supabase.from('weekly_day_off').select('*').eq('status', 'approved'),
          supabase.from('department_shift_rules').select('*'),
          supabase.from('shift_schedules').select('*').gte('shift_date', thirtyDaysAgo),
          supabase.from('shift_preferences').select('*').eq('status', 'approved'),
          supabase.from('system_settings' as any).select('*').in('setting_key', ['general', 'shift_engine_config']),
          supabase.from('shift_dependency_rules').select('*')
        ]);

        const errors = results.map(r => r.error).filter(Boolean);
        if (errors.length > 0) {
            console.error("Shift engine data fetch errors:", errors);
            throw new Error("Veri tabanından bilgiler alınırken hata oluştu. Lütfen sayfayı yenileyin.");
        }

        const [
          { data: personnel },
          { data: movements },
          { data: dayOffs },
          { data: deptRules },
          { data: pastSchedules },
          { data: shiftPrefs },
          { data: settingsData },
          { data: dependencyRules }
        ] = results;

        const generalSettingsRaw = settingsData?.find((s: any) => s.setting_key === 'general');
        const engineConfigRaw = settingsData?.find((s: any) => s.setting_key === 'shift_engine_config');

        const movementTypes = generalSettingsRaw?.setting_value?.movementTypes || [];
        
        // Fallback for UI if totally empty, but primary source is movementTypes
        const activeCodes = movementTypes.length > 0 ? movementTypes : [
          { code: 'S', label: 'Sabah' },
          { code: 'A', label: 'Akşam' },
          { code: 'İ', label: 'İzin' }
        ];

        if (!activeCodes.some((c: any) => c.code === '' || c.code === '-')) {
            activeCodes.unshift({ code: '', label: 'Temizle (-)' });
        }

        return {
          personnel: personnel || [],
          movements: movements || [],
          dayOffs: dayOffs || [],
          deptRules: deptRules || [],
          pastSchedules: pastSchedules || [],
          shiftPrefs: shiftPrefs || [],
          shiftCodes: activeCodes,
          engineConfig: engineConfigRaw?.setting_value || { blockMultipleAbsence: true },
          dependencyRules: dependencyRules || []
        };
    }
  });

  const getWeekDates = (startStr: string) => {
    if (!startStr) return [];
    const dates = [];
    const startObj = new Date(startStr);
    
    // Yıllık timezone/gün kaymasını önlemek için yerel saati kullan ve o haftanın Pazartesisine git
    let day = startObj.getDay();
    if (day === 0) day = 7; // Pazar
    
    // Seçilen tarihten kaç gün geriye gideceğimizi bul (Pazartesiye ulaşmak için)
    const diff = day - 1;
    startObj.setDate(startObj.getDate() - diff);
    
    for (let i = 0; i < 7; i++) {
        const d = new Date(startObj);
        d.setDate(d.getDate() + i);
        
        // Yerel saate göre YYYY-MM-DD formatını güvenli bir şekilde al
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const dayOfMonth = String(d.getDate()).padStart(2, '0');
        dates.push(`${year}-${month}-${dayOfMonth}`);
    }
    return dates;
  };

  const handleGenerate = () => {
    try {
      if (!selectedWeekStart) return toast.error('Lütfen haftanın başlama tarihi (Pazartesi) seçiniz.');
      if (!engineContext) return toast.error('Motor verileri henüz yüklenmedi, lütfen bekleyin.');

      const weekDates = getWeekDates(selectedWeekStart);
      const newGrid: any[] = [];

    const isAbsence = (code: string) => ['İ', 'R', 'Yİ', 'Üİ', 'ÜS', 'T', 'Ü', 'M', 'Y', 'Z', 'X', 'D', 'B'].includes(code);

    const targetOrder = ['Müdür', 'Kadın & Çocuk Reyon', 'Erkek Reyon', 'Kasiyer'];
    const depts = Array.from(new Set(engineContext.personnel.map((p: any) => getVirtualDept(p.department))));
    depts.sort((a, b) => {
      let ia = targetOrder.indexOf(a);
      let ib = targetOrder.indexOf(b);
      if (ia === -1) ia = 999;
      if (ib === -1) ib = 999;
      if (ia !== ib) return ia - ib;
      return a.localeCompare(b);
    });

    let collisionError = "";

    depts.forEach(dept => {
      const deptStaff = engineContext.personnel.filter(p => getVirtualDept(p.department) === dept);
      const rows: any[] = [];
      
      // Step 1: Initialize rows and map absences
      deptStaff.forEach(p => {
        const row: any = { personnel_id: p.id, adSoyad: `${p.first_name || ''} ${p.last_name || ''}`.trim(), department: dept, originalDept: p.department || 'Tanımsız', gender: p.gender, shifts: {}, tasks: {}, preferredShift: {} };
        const pMovements = engineContext.movements.filter(m => m.personnel_id === p.id);
        
        weekDates.forEach((dateStr) => {
            const hasMovement = pMovements.find(m => {
                if (!m.start_date) return false;
                const mStart = m.start_date.substring(0, 10);
                const mEnd = m.end_date ? m.end_date.substring(0, 10) : mStart;
                return mStart <= dateStr && mEnd >= dateStr;
            });
            if (hasMovement && hasMovement.movement_type) {
                row.shifts[dateStr] = hasMovement.movement_type; // e.g. R, Yİ
            }
        });
        rows.push(row);
      });

      // Müdür için atama döngüsünden çık (Tamamen boş kalır)
      if (String(dept).toLowerCase().includes('müdür')) {
          weekDates.forEach((dateStr) => {
             rows.forEach(r => r.shifts[dateStr] = ''); 
          });
          newGrid.push(...rows);
          return; 
      }

      // Step 2: Map explicit Day Offs (Haftalık İzin)
      deptStaff.forEach((p, idx) => {
        const row = rows[idx];
        const pDayOffs = engineContext.dayOffs.filter(d => d.personnel_id === p.id);
        row.debug_dayoffs = pDayOffs;
        
        weekDates.forEach((dateStr) => {
           const [yyyy, mm, dd] = dateStr.split('-');
           const localDate = new Date(Number(yyyy), Number(mm) - 1, Number(dd));
           let dayOfWeek = localDate.getDay();
           if (dayOfWeek === 0) dayOfWeek = 7;

           // DEBUG
           if (!row.debug_days) row.debug_days = {};
           row.debug_days[dateStr] = dayOfWeek;

           if (pDayOffs.some(d => Number(d.day_of_week) === dayOfWeek) && !row.shifts[dateStr]) {
               row.shifts[dateStr] = 'T'; // Haftalık izin (Hafta Tatili)
           }
        });
      });

      // Step 3: Auto-assign missing Day Offs
      deptStaff.forEach((p, idx) => {
        const row = rows[idx];
        const hasDayOff = weekDates.some(d => isAbsence(row.shifts[d]));
        if (!hasDayOff) {
            let assigned = false;
            for (let d = 0; d < 5; d++) {
                const dateStr = weekDates[d];
                const countOff = rows.filter(r => isAbsence(r.shifts[dateStr])).length;
                if (countOff === 0) {
                    row.shifts[dateStr] = 'T';
                    assigned = true;
                    break;
                }
            }
            if (!assigned) row.shifts[weekDates[0]] = 'T'; 
        }
      });

      // Step 4: Collision Check
      if (engineContext.engineConfig?.blockMultipleAbsence !== false) {
          weekDates.forEach(dateStr => {
              const offStaff = rows.filter(r => isAbsence(r.shifts[dateStr]));
              if (offStaff.length >= 2 && deptStaff.length >= 2) {
                  const names = offStaff.map(r => r.adSoyad).join(", ");
                  collisionError = `Hata: ${dept} reyonunda ${names} aynı gün (${dateStr}) izin/rapor durumundadır. Lütfen hareketleri kontrol edin.`;
              }
          });
      }

      // Step 5: Special Requests (Preferences)
      deptStaff.forEach((p, idx) => {
         const row = rows[idx];
         const pPrefs = engineContext.shiftPrefs.filter(sp => sp.personnel_id === p.id);
         weekDates.forEach((dateStr) => {
             const [yyyy, mm, dd] = dateStr.split('-');
             const localDate = new Date(Number(yyyy), Number(mm) - 1, Number(dd));
             let dayOfWeek = localDate.getDay();
             if (dayOfWeek === 0) dayOfWeek = 7;

             const pref = pPrefs.find(sp => Number(sp.day_of_week) === dayOfWeek);
             if (pref && !row.shifts[dateStr]) {
                 row.shifts[dateStr] = pref.requested_shift?.toLowerCase() === 'sabah' ? 'S' : 'A';
             }
         });
      });

      // Step 6: Distribution Algorithm based on ACTIVE staff
      weekDates.forEach((dateStr, dIdx) => {
          const unassignedRows = rows.filter(r => !r.shifts[dateStr]);
          if (unassignedRows.length === 0) return;

          const activeRows = rows.filter(r => !isAbsence(r.shifts[dateStr]));
          const totalActive = activeRows.length; // Remaining active people today
          
          let targetS = 0;
          let targetA = 0;

          // Distribution Rules based on Active Worker Count
          if (totalActive === 2) { targetS = 1; targetA = 1; }
          else if (totalActive === 3) { targetS = 1; targetA = 2; }
          else if (totalActive === 4) { targetS = 2; targetA = 2; }
          else if (totalActive === 5) { targetS = 2; targetA = 3; }
          else if (totalActive === 6) { targetS = 2; targetA = 4; }
          else if (totalActive >= 7) { targetS = 3; targetA = totalActive - 3; }
          else if (totalActive === 1) { targetS = 0; targetA = 1; }

          let currentS = activeRows.filter(r => r.shifts[dateStr] && r.shifts[dateStr].startsWith('S')).length;
          let currentA = activeRows.filter(r => r.shifts[dateStr] && r.shifts[dateStr].startsWith('A')).length;

          // Rotation & Balancing Logic
          unassignedRows.sort((rA, rB) => {
              const prevDateStr = dIdx > 0 ? weekDates[dIdx - 1] : null;
              const rAPrev = prevDateStr ? rA.shifts[prevDateStr] : null;
              const rBPrev = prevDateStr ? rB.shifts[prevDateStr] : null;

              let scoreA = 0; // High score = give S, Low score = give A
              let scoreB = 0;

              // 1. Rotation (Avoid same shift consecutively)
              if (rAPrev === 'S') scoreA -= 20; // Needs A
              if (rAPrev === 'A') scoreA += 20; // Needs S

              if (rBPrev === 'S') scoreB -= 20;
              if (rBPrev === 'A') scoreB += 20;

              // 2. Weekly Max 4 Evenings (Adalet Kuralı)
              const rAWeekAksam = weekDates.filter(d => ['A', 'A+M', 'A+D'].includes(rA.shifts[d])).length;
              const rBWeekAksam = weekDates.filter(d => ['A', 'A+M', 'A+D'].includes(rB.shifts[d])).length;

              const rAWeekSabah = weekDates.filter(d => ['S', 'S+M', 'S+D'].includes(rA.shifts[d])).length;
              const rBWeekSabah = weekDates.filter(d => ['S', 'S+M', 'S+D'].includes(rB.shifts[d])).length;

              if (rAWeekAksam >= 4) scoreA += 100; // Force S
              if (rBWeekAksam >= 4) scoreB += 100;

              // 2.5 Weekly MIN 3 Evenings Rule
              const remainingDays = 7 - dIdx;
              if (rAWeekAksam + remainingDays <= 3) scoreA -= 200; // MUST give A
              if (rBWeekAksam + remainingDays <= 3) scoreB -= 200; // MUST give A

              // 2.6 If unbalanced, Evening must be greater than Morning
              if (rAWeekSabah > rAWeekAksam) scoreA -= 150; // Needs A heavily
              if (rBWeekSabah > rBWeekAksam) scoreB -= 150; // Needs A heavily

              // 3. Preferences (Onaylı Tercihler)
              if (rA.preferredShift[dateStr] === 'S') scoreA += 50;
              if (rA.preferredShift[dateStr] === 'A') scoreA -= 50;

              if (rB.preferredShift[dateStr] === 'S') scoreB += 50;
              if (rB.preferredShift[dateStr] === 'A') scoreB -= 50;

              // 4. Monthly Balance
              const pastSabahCountA = engineContext.pastSchedules.filter(s => s.personnel_id === rA.personnel_id && ['S', 'Sabah'].includes(s.shift_type)).length;
              const pastAksamCountA = engineContext.pastSchedules.filter(s => s.personnel_id === rA.personnel_id && ['A', 'Akşam'].includes(s.shift_type)).length;
              if (pastAksamCountA > pastSabahCountA) scoreA += 10; // Needs S

              const pastSabahCountB = engineContext.pastSchedules.filter(s => s.personnel_id === rB.personnel_id && ['S', 'Sabah'].includes(s.shift_type)).length;
              const pastAksamCountB = engineContext.pastSchedules.filter(s => s.personnel_id === rB.personnel_id && ['A', 'Akşam'].includes(s.shift_type)).length;
              if (pastAksamCountB > pastSabahCountB) scoreB += 10;

              return scoreB - scoreA; // Descending order (highest score gets S first)
          });

          // Assignment loop
          unassignedRows.forEach(row => {
             let assignS = false;
             
             if (currentS < targetS && currentA < targetA) {
                 assignS = true; // Top scorer gets S
             } else if (currentS < targetS) {
                 assignS = true; // Forced S because A is full
             } else {
                 assignS = false; // Forced A because S is full
             }

             if (assignS) {
                 row.shifts[dateStr] = 'S';
                 currentS++;
             } else {
                 row.shifts[dateStr] = 'A';
                 currentA++;
             }
          });
      });

      newGrid.push(...rows);
    });

    // Step 7: Cross-Department Dependency Rules (Second Pass Override)
    if (engineContext.dependencyRules && engineContext.dependencyRules.length > 0) {
        engineContext.dependencyRules.forEach((rule: any) => {
            const targetDeptRows = newGrid.filter(r => getVirtualDept(r.originalDept) === getVirtualDept(rule.target_department));
            const supportPersonRow = newGrid.find(r => r.personnel_id === rule.personnel_id);

            if (!supportPersonRow || targetDeptRows.length === 0) return;

            weekDates.forEach(dateStr => {
                // If support person is already absent (Off, Report, etc), do not override
                if (isAbsence(supportPersonRow.shifts[dateStr])) return;

                // Count absences in target dept
                const absentCount = targetDeptRows.filter(r => isAbsence(r.shifts[dateStr])).length;
                
                // If absences reach the trigger count
                if (absentCount >= (rule.trigger_absence_count || 1)) {
                    // Check if the remaining active staff match the trigger shift type
                    // If trigger_shift_type is 'S', we check if AT LEAST ONE of the remaining staff has 'S'
                    let shiftConditionMet = false;
                    
                    if (rule.trigger_shift_type && rule.trigger_shift_type !== '-') {
                        const activeStaff = targetDeptRows.filter(r => !isAbsence(r.shifts[dateStr]));
                        shiftConditionMet = activeStaff.some(r => r.shifts[dateStr] && r.shifts[dateStr].startsWith(rule.trigger_shift_type));
                    } else {
                        // If no specific shift type is required, just checking absence is enough
                        shiftConditionMet = true;
                    }

                    if (shiftConditionMet) {
                        supportPersonRow.shifts[dateStr] = rule.action_shift_type || 'A';
                    }
                }
            });
        });
    }

    const finalOrder = ['müdür', 'kasiyer', 'çocuk', 'kadın', 'bayan', 'erkek'];
    newGrid.sort((a, b) => {
        const aDept = String(a.originalDept || '').toLocaleLowerCase('tr-TR');
        const bDept = String(b.originalDept || '').toLocaleLowerCase('tr-TR');

        let ia = finalOrder.findIndex(dept => aDept.includes(dept));
        let ib = finalOrder.findIndex(dept => bDept.includes(dept));

        if (ia === -1) ia = 999;
        if (ib === -1) ib = 999;

        if (ia !== ib) return ia - ib;
        return String(a.adSoyad || '').localeCompare(String(b.adSoyad || ''), 'tr-TR');
    });

    if (collisionError) {
        toast.error(collisionError, { duration: 8000 });
        return; 
    }

    if (newGrid.length === 0) {
        toast.error('Aktif personel bulunamadığı için liste oluşturulamadı.');
        return;
    }

    let finalGrid = newGrid;
    finalGrid = assignTasksToGrid(finalGrid, 'Depo', 'A');
    finalGrid = assignTasksToGrid(finalGrid, 'Mutfak', 'S');

    setGeneratedGrid(finalGrid);
    setIsGenerated(true);
    toast.success('Haftalık Vardiya Listesi Taslağı Oluşturuldu! Düzenleyip kaydedebilirsiniz.');
    } catch (err: any) {
      console.error("Vardiya oluşturma hatası:", err);
      toast.error("Motor çalışırken bir hata oluştu: " + err.message);
    }
  };

  const handleCellChange = (pId: string, dateStr: string, val: string) => {
      setGeneratedGrid(prev => prev.map(row => {
          if (row.personnel_id === pId) {
              const newShifts = { ...row.shifts };
              const newTasks = { ...row.tasks };
              if (val === '') {
                  delete newShifts[dateStr];
              } else {
                  newShifts[dateStr] = val;
              }
              return { ...row, shifts: newShifts, tasks: newTasks };
          }
          return row;
      }));
  };

  const handleTaskChange = (pId: string, dateStr: string, taskVal: string) => {
      setGeneratedGrid(prev => prev.map(row => {
          if (row.personnel_id === pId) {
              const newTasks = { ...row.tasks };
              const newShifts = { ...row.shifts };
              let currentShift = newShifts[dateStr] || '';
              
              currentShift = currentShift.replace('+M', '').replace('+D', '');
              
              if (taskVal === '') {
                  delete newTasks[dateStr];
              } else {
                  newTasks[dateStr] = taskVal;
              }
              newShifts[dateStr] = currentShift;
              
              return { ...row, tasks: newTasks, shifts: newShifts };
          }
          return row;
      }));
  };

  const assignTasksToGrid = (currentGrid: any[], taskName: 'Depo' | 'Mutfak', targetShift: 'A' | 'S') => {
      const config = taskName === 'Depo' ? engineContext?.engineConfig?.depo_config : engineContext?.engineConfig?.mutfak_config;
      const c = config || { count: 0, gender: 'Tümü', departments: [], included_personnel: [], excluded_personnel: [] };
      const targetCount = c.count || 0;
      
      if (targetCount === 0 && (!c.included_personnel || c.included_personnel.length === 0)) {
          return currentGrid;
      }
      
      const weekDates = getWeekDates(selectedWeekStart);
      const newGrid = currentGrid.map(row => ({ ...row, tasks: { ...row.tasks }, shifts: { ...row.shifts } }));
      
      weekDates.forEach((dateStr) => {
          const dt = new Date(dateStr);
          const dayOfWeek = dt.getDay() === 0 ? 7 : dt.getDay(); // 1=Mon, 7=Sun
          
          if (c.active_days && c.active_days.length > 0 && !c.active_days.includes(dayOfWeek)) {
              return; 
          }

          newGrid.forEach(r => { 
              if (r.tasks && r.tasks[dateStr] === taskName) {
                  delete r.tasks[dateStr]; 
                  if (r.shifts && r.shifts[dateStr]) {
                      r.shifts[dateStr] = r.shifts[dateStr].replace(taskName === 'Mutfak' ? '+M' : '+D', '');
                  }
              }
          });
          
          let candidates = newGrid.filter(r => {
             const s = r.shifts[dateStr];
             if (!s) return false;
             if (r.tasks && r.tasks[dateStr] && r.tasks[dateStr] !== taskName) return false; 
             
             if (c.valid_shifts && c.valid_shifts.length > 0) {
                 return c.valid_shifts.some((vs: string) => {
                     const cleanVs = vs.replace('+M', '').replace('+D', '');
                     const cleanS = s.replace('+M', '').replace('+D', '');
                     return cleanVs === cleanS || cleanS.startsWith(cleanVs);
                 });
             } else {
                 return s.startsWith(targetShift);
             }
          });
          
          if (c.excluded_personnel && c.excluded_personnel.length > 0) {
              candidates = candidates.filter(r => !c.excluded_personnel.includes(r.personnel_id));
          }
          
          let forcedCandidates = candidates.filter(r => c.included_personnel && c.included_personnel.includes(r.personnel_id));
          let regularCandidates = candidates.filter(r => !c.included_personnel || !c.included_personnel.includes(r.personnel_id));
          
          if (c.gender && c.gender !== 'Tümü') {
              regularCandidates = regularCandidates.filter(r => r.gender === c.gender);
          }
          
          if (c.departments && c.departments.length > 0) {
              regularCandidates = regularCandidates.filter(r => c.departments.includes(r.originalDept));
          }
          
          // Adil dağıtım (Fair Distribution) algoritması:
          // Her personelin bu hafta şu ana kadar kaç kez bu görevi aldığını say
          const sortByTaskCount = (a: any, b: any) => {
              const countA = Object.values(a.tasks || {}).filter(t => t === taskName).length;
              const countB = Object.values(b.tasks || {}).filter(t => t === taskName).length;
              if (countA !== countB) return countA - countB; // Az görev alan öncelikli
              return 0.5 - Math.random(); // Eşitse rastgele
          };

          forcedCandidates.sort(sortByTaskCount);
          regularCandidates.sort(sortByTaskCount);
          
          // Günlük hedefi kesinlikle aşmamak için slice() kullan
          const selectedForced = forcedCandidates.slice(0, targetCount);
          const remainingCount = Math.max(0, targetCount - selectedForced.length);
          const selected = [...selectedForced, ...regularCandidates.slice(0, remainingCount)];
          
          selected.forEach(r => { 
              if (!r.tasks) r.tasks = {};
              r.tasks[dateStr] = taskName; 
          });
      });
      return newGrid;
  };

  const handleAssignTasks = (taskName: 'Depo' | 'Mutfak', targetShift: 'A' | 'S') => {
      if (!generatedGrid.length) return;
      
      const config = taskName === 'Depo' ? engineContext?.engineConfig?.depo_config : engineContext?.engineConfig?.mutfak_config;
      const c = config || { count: 0, gender: 'Tümü', departments: [], included_personnel: [], excluded_personnel: [] };
      const targetCount = c.count || 0;
      
      if (targetCount === 0 && (!c.included_personnel || c.included_personnel.length === 0)) {
          return toast.info(`Ayarlarda ${taskName} çalışan hedefi 0 olarak belirlenmiş.`);
      }
      
      const newGrid = assignTasksToGrid(generatedGrid, taskName, targetShift);
      setGeneratedGrid(newGrid);
      toast.success(`${taskName} görevleri detaylı kurallara göre dağıtıldı.`);
  };

  const handleLoadSavedWeek = (weekStart: string) => {
      setSelectedWeekStart(weekStart);
      const weekDates = getWeekDates(weekStart);
      const newGrid: any[] = [];
      engineContext?.personnel.forEach((p: any) => {
          newGrid.push({ personnel_id: p.id, adSoyad: `${p.first_name || ''} ${p.last_name || ''}`.trim(), department: getVirtualDept(p.department), originalDept: p.department || 'Tanımsız', gender: p.gender, shifts: {}, tasks: {}, preferredShift: {} });
      });

      const weekSchedules = engineContext?.pastSchedules.filter((s: any) => s.week_start_date === weekStart) || [];
      weekSchedules.forEach((s: any) => {
          const row = newGrid.find(r => r.personnel_id === s.personnel_id);
          if (row) {
              row.shifts[s.shift_date] = s.shift_type;
              if (s.task_assignment) {
                  row.tasks[s.shift_date] = s.task_assignment;
              } else {
                  if (s.shift_type?.includes('+M')) row.tasks[s.shift_date] = 'Mutfak';
                  if (s.shift_type?.includes('+D')) row.tasks[s.shift_date] = 'Depo';
              }
          }
      });

      const finalOrder = ['müdür', 'kasiyer', 'çocuk', 'kadın', 'bayan', 'erkek'];
      newGrid.sort((a, b) => {
          const aDept = String(a.originalDept || '').toLocaleLowerCase('tr-TR');
          const bDept = String(b.originalDept || '').toLocaleLowerCase('tr-TR');
          let ia = finalOrder.findIndex(dept => aDept.includes(dept));
          let ib = finalOrder.findIndex(dept => bDept.includes(dept));
          if (ia === -1) ia = 999;
          if (ib === -1) ib = 999;
          if (ia !== ib) return ia - ib;
          return String(a.adSoyad || '').localeCompare(String(b.adSoyad || ''), 'tr-TR');
      });

      setGeneratedGrid(newGrid);
      setIsGenerated(true);
      toast.success(`${formatDateTR(weekStart)} haftası ekrana yüklendi. Düzenleme yapabilirsiniz.`);
  };

  const deleteSavedWeekMutation = useMutation({
      mutationFn: async (weekStart: string) => {
          const { error } = await supabase.from('shift_schedules').delete().eq('week_start_date', weekStart);
          if (error) throw error;
      },
      onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['shift_engine_context'] });
          toast.success('Haftalık liste kalıcı olarak silindi.');
      }
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
        const weekDates = getWeekDates(selectedWeekStart);
        // Wipe existing for this week to allow recreation
        const { error: delErr } = await supabase.from('shift_schedules').delete().in('shift_date', weekDates);
        
        const inserts: any[] = [];
        generatedGrid.forEach(row => {
            weekDates.forEach(dateStr => {
                const shift_type = row.shifts[dateStr] || 'A';
                inserts.push({
                    personnel_id: row.personnel_id,
                    shift_date: dateStr,
                    shift_type: shift_type,
                    task_assignment: row.tasks[dateStr] || null,
                    week_start_date: selectedWeekStart,
                    is_manual_override: true
                });
            });
        });

        // Add chunking if needed for large teams, using single insert for now
        const { error: insErr } = await supabase.from('shift_schedules').insert(inserts);
        if (insErr) throw insErr;
    },
    onSuccess: () => {
        toast.success("Vardiya Listesi Başarıyla Veritabanına Kaydedildi!");
        queryClient.invalidateQueries({ queryKey: ['shift_schedules'] });
    },
    onError: (e: any) => {
        toast.error("Vardiya kaydedilirken hata oluştu: " + e.message);
    }
  });

  const generateExcel = (type: 'vardiya' | 'depo' | 'mutfak') => {
    if (!isGenerated) return;
    const weekDates = getWeekDates(selectedWeekStart);
    const targetOrder = ['Müdür', 'Kadın & Çocuk Reyon', 'Erkek Reyon', 'Kasiyer'];
    
    // Filtreleme (Depo/Mutfak seçildiyse sadece o görevi alanları göster)
    let gridToExport = generatedGrid;
    if (type === 'depo') {
        gridToExport = generatedGrid.filter(r => Object.values(r.tasks || {}).includes('Depo'));
    } else if (type === 'mutfak') {
        gridToExport = generatedGrid.filter(r => Object.values(r.tasks || {}).includes('Mutfak'));
    }

    const currentDepts = Array.from(new Set(gridToExport.map(r => r.department)));
    currentDepts.sort((a, b) => {
      let ia = targetOrder.indexOf(a);
      let ib = targetOrder.indexOf(b);
      if (ia === -1) ia = 999;
      if (ib === -1) ib = 999;
      if (ia !== ib) return ia - ib;
      return String(a).localeCompare(String(b));
    });
    
    const exportData: any[] = [];
    currentDepts.forEach(dept => {
        const deptRows = gridToExport.filter(r => r.department === dept);
        deptRows.forEach(row => {
          const obj: any = { 'Grup': row.department, 'Orijinal Departman': row.originalDept, 'Ad Soyad': row.adSoyad };
          weekDates.forEach((dateStr, i) => { 
              if (type === 'vardiya') {
                  obj[`${DAYS[i]} (${dateStr})`] = row.shifts[dateStr] || '-';
              } else if (type === 'depo') {
                  obj[`${DAYS[i]} (${dateStr})`] = row.tasks[dateStr] === 'Depo' ? 'D' : '-';
              } else if (type === 'mutfak') {
                  obj[`${DAYS[i]} (${dateStr})`] = row.tasks[dateStr] === 'Mutfak' ? 'M' : '-';
              }
          });
          exportData.push(obj);
        });
        
        exportData.push({});
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    const sheetName = type === 'vardiya' ? 'Vardiya' : type === 'depo' ? 'Depo' : 'Mutfak';
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    XLSX.writeFile(wb, `${sheetName}_Listesi_${selectedWeekStart}.xlsx`);
  };

  return (
    <Card className="border shadow-sm print:border-none print:shadow-none print:m-0">
      <CardHeader className="border-b bg-muted/30 pb-6 print:hidden">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <CardTitle className="text-xl">Vardiya Motoru</CardTitle>
            <CardDescription>Otomatik dengeleme motorunu başlatarak taslak listeyi görün. Müdahale edip kaydedin.</CardDescription>
          </div>
          <div className="flex flex-col gap-2 md:items-end">
            <div className="flex items-center gap-3">
              <div className="border rounded-lg bg-background flex items-center px-2 shadow-sm">
                 <CalIcon className="w-4 h-4 text-muted-foreground mr-2"/>
                 <input 
                   type="date" 
                   className="outline-none py-2 text-sm bg-transparent" 
                   value={selectedWeekStart} 
                   onChange={e => setSelectedWeekStart(e.target.value)}
                   title="Haftanın Pazartesi Günü"
                 />
              </div>
              <Button onClick={handleGenerate} className="bg-indigo-600 hover:bg-indigo-700 text-white"><Settings2 className="w-4 h-4 mr-2"/> Otomatik Hazırla</Button>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-6 print:p-0 print:m-0">
        {isLoading && <div className="text-center p-8 animate-pulse text-muted-foreground">Motor verileri yükleniyor...</div>}
        
        {!isLoading && engineContext !== undefined && (() => {
           const savedWeeks = Array.from(new Set(engineContext.pastSchedules.map((s: any) => s.week_start_date))).sort().reverse().slice(0, 8) as string[];
           if (savedWeeks.length === 0) return null;
           return (
             <div className="mb-8 p-4 border rounded-xl bg-muted/10 print:hidden">
                <h3 className="text-sm font-semibold mb-3 text-muted-foreground uppercase tracking-wider">Kayıtlı Geçmiş Haftalar (Son 8 Hafta)</h3>
                <div className="flex flex-wrap gap-3">
                  {savedWeeks.map((weekStart, i) => (
                      <div key={weekStart} className="flex items-center bg-white dark:bg-black border shadow-sm rounded-lg overflow-hidden">
                          <div className="px-3 py-2 bg-indigo-50 dark:bg-indigo-900/20 border-r border-indigo-100 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 font-medium text-sm flex items-center gap-2">
                             <CalIcon className="w-4 h-4" />
                             {i + 1}. Hafta: {formatDateTR(weekStart)}
                          </div>
                          <div className="flex">
                             <button onClick={() => handleLoadSavedWeek(weekStart)} className="px-3 py-2 text-xs hover:bg-muted font-medium transition-colors border-r" title="Düzenle">Düzenle</button>
                             <button onClick={() => deleteSavedWeekMutation.mutate(weekStart)} disabled={deleteSavedWeekMutation.isPending} className="px-3 py-2 text-xs text-red-600 hover:bg-red-50 font-medium transition-colors" title="Sil">Sil</button>
                          </div>
                      </div>
                  ))}
                </div>
             </div>
           );
        })()}

        {engineContext === undefined && !isLoading && (
            <div className="flex flex-col items-center justify-center p-12 lg:p-24 border-2 border-dashed border-red-200 rounded-xl bg-red-50 dark:bg-red-900/10">
                <h3 className="text-lg font-semibold text-red-600">Veri Yükleme Hatası</h3>
                <p className="text-sm text-center text-red-500/80 max-w-sm mt-2">Vardiya kuralları ve personel bilgileri sunucudan alınamadı. Lütfen sayfayı yenileyin veya internet bağlantınızı kontrol edin.</p>
                <Button variant="outline" className="mt-4 border-red-200 text-red-600 hover:bg-red-100" onClick={() => window.location.reload()}><RefreshCw className="w-4 h-4 mr-2" /> Sayfayı Yenile</Button>
            </div>
        )}

        {!isLoading && !isGenerated && engineContext !== undefined && (
            <div className="flex flex-col items-center justify-center p-12 lg:p-24 border-2 border-dashed rounded-xl bg-muted/10">
                <RefreshCw className="w-12 h-12 text-muted-foreground/30 mb-4" />
                <h3 className="text-lg font-semibold text-foreground">Vardiya Listesi Bekliyor</h3>
                <p className="text-sm text-center text-muted-foreground max-w-sm mt-1">Yukarıdan başlama tarihi (Pazartesi) seçip "Otomatik Hazırla" butonuna tıklayarak taslak oluşturabilirsiniz.</p>
            </div>
        )}

        {isGenerated && generatedGrid.length > 0 && engineContext !== undefined && (
          <div className="space-y-4 animate-fade-in">
             <div className="flex justify-between items-center bg-primary/5 p-3 rounded-lg border border-primary/20 print:hidden">
                <p className="text-sm font-medium">✨ Taslak tablo oluşturuldu. Hücrelere tıklayarak "S", "A", "İ", "R" değerlerini manuel değiştirebilirsiniz.</p>
                <div className="flex gap-2">
                    <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => generateExcel('vardiya')} className="text-indigo-600 border-indigo-200 hover:bg-indigo-50"><FileDown className="w-4 h-4 mr-1"/> Vardiya Excel</Button>
                        <Button variant="outline" size="sm" onClick={() => generateExcel('depo')} className="text-blue-600 border-blue-200 hover:bg-blue-50"><FileDown className="w-4 h-4 mr-1"/> Depo Excel</Button>
                        <Button variant="outline" size="sm" onClick={() => generateExcel('mutfak')} className="text-amber-600 border-amber-200 hover:bg-amber-50"><FileDown className="w-4 h-4 mr-1"/> Mutfak Excel</Button>
                        <Button variant="outline" size="sm" onClick={() => window.print()} className="text-gray-600 border-gray-200 hover:bg-gray-50"><Printer className="w-4 h-4 mr-1"/> Yazdır</Button>
                    </div>
                    <Button size="sm" onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>{saveMutation.isPending ? 'Kaydediliyor...' : 'Onayla ve Kaydet'}</Button>
                </div>
             </div>

             <div className="border border-black/30 rounded-xl overflow-hidden mt-4 shadow-sm bg-white">
                 <div className="overflow-x-auto">
                    <table className="w-full text-sm border-collapse text-black">
                       <thead>
                          <tr className="bg-gray-200 text-center border-b-2 border-black/40">
                             <th className="border-r border-black/20 p-1.5 w-10 font-bold"></th>
                             <th className="border-r border-black/20 p-1.5 w-[200px] font-bold text-left pl-3">ADI SOYADI</th>
                             <th className="border-r border-black/20 p-1.5 w-[140px] font-bold text-left pl-3">GÖREVİ</th>
                             {getWeekDates(selectedWeekStart).map((dateStr, i) => (
                                 <th key={dateStr} className="border-r border-black/20 p-1.5 w-[85px]">
                                     <div className="font-bold">{DAYS_TR[i]}</div>
                                     <div className="font-normal italic text-[11px] leading-tight">{formatDateTR(dateStr)}</div>
                                 </th>
                             ))}
                             <th className="p-1.5 w-16 bg-yellow-200 border-l-2 border-black/40 font-bold text-red-600 print:hidden">AKŞAM</th>
                          </tr>
                       </thead>
                       <tbody>
                           {(() => {
                            const finalOrder = ['müdür', 'kasiyer', 'çocuk', 'kadın', 'bayan', 'erkek'];
                            const currentDepts = Array.from(new Set(generatedGrid.map(r => r.originalDept || 'Tanımsız')));
                            currentDepts.sort((a, b) => {
                              let ia = finalOrder.findIndex(dept => String(a || '').toLocaleLowerCase('tr-TR').includes(dept));
                              let ib = finalOrder.findIndex(dept => String(b || '').toLocaleLowerCase('tr-TR').includes(dept));
                              if (ia === -1) ia = 999;
                              if (ib === -1) ib = 999;
                              if (ia !== ib) return ia - ib;
                              return String(a || '').localeCompare(String(b || ''), 'tr-TR');
                            });

                            let globalRowCounter = 1;
                            const deptTotals: any[] = []; // for daily summary table

                            return (
                                <>
                                {currentDepts.map((dept, deptIdx) => {
                                    const deptRows = generatedGrid.filter(r => r.originalDept === dept);
                                    if (deptRows.length === 0) return null;

                                    const dailyTotals = getWeekDates(selectedWeekStart).map(dateStr => {
                                        let sabahCount = 0;
                                        let aksamCount = 0;
                                        deptRows.forEach(r => {
                                            const val = r.shifts[dateStr] || '';
                                            if (val.startsWith('S')) sabahCount++;
                                            else if (val.startsWith('A')) aksamCount++;
                                        });
                                        return { sabah: sabahCount, aksam: aksamCount };
                                    });
                                    deptTotals.push({ dept, dailyTotals });

                                    return (
                                      <Fragment key={dept}>
                                          {deptRows.map((row, rIdx) => {
                                              const aksamTotal = getWeekDates(selectedWeekStart).filter(d => (row.shifts[d] || '').startsWith('A')).length;
                                              return (
                                                  <tr key={row.personnel_id} className="border-b border-black/20 hover:bg-black/5">
                                                      <td className="text-center font-bold text-xs border-r border-black/20">{globalRowCounter++}</td>
                                                      <td className="font-bold border-r border-black/20 pl-3 uppercase">
                                                          {row.adSoyad}
                                                      </td>
                                                      <td className="font-bold italic text-xs border-r border-black/20 pl-3 uppercase">{row.originalDept}</td>
                                                      {getWeekDates(selectedWeekStart).map(dateStr => {
                                                          const val = row.shifts[dateStr] || '';
                                                          const isSpecial = val && val !== 'S' && val !== 'A';
                                                          return (
                                                              <td key={dateStr} className={`p-0 border-r border-black/20 ${isSpecial ? 'bg-rose-100' : ''}`}>
                                                                  <select 
                                                                    className={`w-full h-full min-h-[32px] text-center outline-none font-bold text-sm cursor-pointer hover:bg-black/5 appearance-none ${isSpecial ? 'bg-rose-100 text-rose-700' : 'bg-transparent text-black'}`}
                                                                    value={val}
                                                                    onChange={e => handleCellChange(row.personnel_id, dateStr, e.target.value)}
                                                                  >
                                                                    <option value="">-</option>
                                                                    {engineContext.shiftCodes.map((c: any) => (
                                                                        <option key={c.code} value={c.code} title={c.label}>{c.code}</option>
                                                                    ))}
                                                                    {val && !engineContext.shiftCodes.some((c: any) => c.code === val) && (
                                                                        <option value={val}>{val}</option>
                                                                    )}
                                                                  </select>
                                                              </td>
                                                          );
                                                      })}
                                                      <td className="text-center font-bold border-l-2 border-black/40 print:hidden">{aksamTotal > 0 ? aksamTotal : ''}</td>
                                                  </tr>
                                              );
                                          })}
                                          {/* Alt toplam satırı ve Boş satır ile reyonları ayır */}
                                          {(() => {
                                              const currentVirtual = getVirtualDept(dept);
                                              const nextDept = deptIdx < currentDepts.length - 1 ? currentDepts[deptIdx + 1] : null;
                                              const nextVirtual = nextDept ? getVirtualDept(nextDept) : null;
                                              
                                              if (currentVirtual === nextVirtual) {
                                                  // Aynı birleşik gruptayız (örn. Çocuk -> Kadın geçişi), araya toplam veya boşluk koyma
                                                  return null;
                                              }

                                              // Grubun (Sanal Reyonun) sonuna geldik, toplam satırını oluştur
                                              const vDeptRows = generatedGrid.filter(r => getVirtualDept(r.originalDept) === currentVirtual);

                                              return (
                                                  <Fragment key={`sum-${dept}`}>
                                                      <tr className="bg-indigo-50 border-b-2 border-indigo-200 print:hidden">
                                                          <td colSpan={3} className="text-right font-bold text-[11px] pr-2 py-1.5 text-indigo-800 uppercase">
                                                              {currentVirtual} Toplam:
                                                          </td>
                                                          {getWeekDates(selectedWeekStart).map(dateStr => {
                                                              let s = 0, a = 0;
                                                              vDeptRows.forEach(r => {
                                                                  const v = r.shifts[dateStr] || '';
                                                                  if (v.startsWith('S')) s++;
                                                                  if (v.startsWith('A')) a++;
                                                              });
                                                              return (
                                                                  <td key={`sum-${dateStr}`} className="text-center font-bold text-[11px] text-indigo-800 border-r border-indigo-200 py-1.5 whitespace-nowrap">
                                                                      {s > 0 || a > 0 ? `S-${s} A-${a}` : '-'}
                                                                  </td>
                                                              );
                                                          })}
                                                          <td className="border-l-2 border-black/40 bg-gray-50"></td>
                                                      </tr>
                                                      
                                                      {deptIdx < currentDepts.length - 1 && (
                                                          <tr className="h-6 print:h-3 border-b-2 border-black/40 bg-gray-50">
                                                              <td colSpan={11}></td>
                                                          </tr>
                                                      )}
                                                  </Fragment>
                                              );
                                          })()}
                                      </Fragment>
                                    );
                                })}

                                {/* En alt Genel Özet Tablosu */}
                                <tr className="h-8 border-t-4 border-black/60 bg-gray-100 print:hidden">
                                    <td colSpan={11}></td>
                                </tr>
                                <tr className="bg-yellow-200 border-y border-black/40 font-bold text-red-600 text-center print:hidden">
                                    <td colSpan={3} className="text-right pr-4 border-r border-black/40">AKŞAM TOPLAM</td>
                                    {getWeekDates(selectedWeekStart).map((dateStr, i) => {
                                        const sumA = deptTotals.reduce((acc, curr) => acc + curr.dailyTotals[i].aksam, 0);
                                        return <td key={dateStr} className="border-r border-black/40 text-black">{sumA}</td>;
                                    })}
                                    <td className="bg-gray-100 border-l-2 border-black/40"></td>
                                </tr>
                                <tr className="bg-yellow-100 border-b-2 border-black/40 font-bold text-red-600 text-center print:hidden">
                                    <td colSpan={3} className="text-right pr-4 border-r border-black/40">SABAH TOPLAM</td>
                                    {getWeekDates(selectedWeekStart).map((dateStr, i) => {
                                        const sumS = deptTotals.reduce((acc, curr) => acc + curr.dailyTotals[i].sabah, 0);
                                        return <td key={dateStr} className="border-r border-black/40 text-black">{sumS}</td>;
                                    })}
                                    <td className="bg-gray-100 border-l-2 border-black/40"></td>
                                </tr>
                                </>
                            );
                          })()}
                        </tbody>
                     </table>
                  </div>
              </div>

              {/* Mutfak Çalışması Tablosu */}
              <div className="mt-8 pt-6 border-t-2 border-dashed">
                      <div className="flex justify-between items-center mb-4 print:hidden">
                          <div className="flex items-center gap-4">
                              <h3 className="text-lg font-bold text-amber-600 flex items-center">Mutfak Çalışması</h3>
                              <div className="flex items-center gap-2 border rounded-full px-3 py-1 bg-muted/20 print:hidden">
                                  <Switch id="toggleMutfak" checked={showOnlyAssignedTasks} onCheckedChange={setShowOnlyAssignedTasks} className="scale-75" />
                                  <Label htmlFor="toggleMutfak" className="text-xs cursor-pointer text-muted-foreground select-none">Sadece Görevliler</Label>
                              </div>
                          </div>
                          <Button onClick={() => handleAssignTasks('Mutfak', 'S')} size="sm" variant="outline" className="border-amber-200 hover:bg-amber-50 text-amber-700 print:hidden">Otomatik Mutfak Dağıt</Button>
                      </div>
                  <div className="bg-white border-2 border-amber-200 shadow-md rounded-xl overflow-hidden">
                     <table className="w-full text-left border-collapse text-xs md:text-sm">
                        <thead className="bg-amber-100 text-amber-900 border-b-2 border-amber-200">
                           <tr className="hidden print:table-row bg-amber-200">
                               <th colSpan={10} className="p-2 text-center text-sm font-bold border-b-2 border-amber-300 uppercase tracking-widest text-amber-900">MUTFAK ÇALIŞMASI LİSTESİ</th>
                           </tr>
                           <tr>
                              <th className="p-2 border-r border-amber-200 w-8 text-center font-bold">#</th>
                              <th className="p-2 border-r border-amber-200 w-48 font-bold">Ad Soyad</th>
                              <th className="p-2 border-r border-amber-200 font-bold hidden sm:table-cell">Grup</th>
                              {getWeekDates(selectedWeekStart).map(dateStr => (
                                  <th key={dateStr} className="p-2 border-r border-amber-200 text-center font-bold w-12">{formatDateTR(dateStr)}</th>
                              ))}
                           </tr>
                        </thead>
                        <tbody className="divide-y divide-amber-100">
                           {generatedGrid
                               .filter(row => showOnlyAssignedTasks ? Object.values(row.tasks || {}).includes('Mutfak') : true)
                               .map((row, idx) => (
                               <tr key={`m-${row.personnel_id}`} className="hover:bg-amber-50/50">
                                   <td className="p-2 border-r border-amber-100 text-center text-amber-600 font-medium">{idx + 1}</td>
                                   <td className="p-2 border-r border-amber-100 font-medium text-gray-800">{row.adSoyad}</td>
                                   <td className="p-2 border-r border-amber-100 text-gray-500 hidden sm:table-cell">{row.department}</td>
                                   {getWeekDates(selectedWeekStart).map(dateStr => (
                                       <td key={`m-${row.personnel_id}-${dateStr}`} className="p-1 border-r border-amber-100 text-center">
                                           {row.shifts[dateStr] ? (
                                               <button 
                                                 onClick={() => handleTaskChange(row.personnel_id, dateStr, row.tasks[dateStr] === 'Mutfak' ? '' : 'Mutfak')}
                                                 className={`w-full py-1 rounded transition-colors ${row.tasks[dateStr] === 'Mutfak' ? 'bg-amber-500 text-white font-bold' : 'bg-gray-100 text-gray-400 hover:bg-amber-200'}`}
                                               >
                                                 {row.tasks[dateStr] === 'Mutfak' ? 'M' : '-'}
                                               </button>
                                           ) : (
                                               <div className="w-full py-1 bg-gray-50 text-gray-300 rounded">-</div>
                                           )}
                                       </td>
                                   ))}
                               </tr>
                           ))}
                        </tbody>
                     </table>
                  </div>
              </div>

              {/* Depo Çalışması Tablosu */}
              <div className="mt-8 pt-6 border-t-2 border-dashed">
                  <div className="flex justify-between items-center mb-4 print:hidden">
                      <div className="flex items-center gap-4">
                          <h3 className="text-lg font-bold text-blue-600 flex items-center">Depo Çalışması</h3>
                          <div className="flex items-center gap-2 border rounded-full px-3 py-1 bg-muted/20 print:hidden">
                              <Switch id="toggleDepo" checked={showOnlyAssignedTasks} onCheckedChange={setShowOnlyAssignedTasks} className="scale-75" />
                              <Label htmlFor="toggleDepo" className="text-xs cursor-pointer text-muted-foreground select-none">Sadece Görevliler</Label>
                          </div>
                      </div>
                      <Button onClick={() => handleAssignTasks('Depo', 'A')} size="sm" variant="outline" className="border-blue-200 hover:bg-blue-50 text-blue-700 print:hidden">Otomatik Depo Dağıt</Button>
                  </div>
                  <div className="bg-white border-2 border-blue-200 shadow-md rounded-xl overflow-hidden">
                     <table className="w-full text-left border-collapse text-xs md:text-sm">
                        <thead className="bg-blue-100 text-blue-900 border-b-2 border-blue-200">
                           <tr className="hidden print:table-row bg-blue-200">
                               <th colSpan={10} className="p-2 text-center text-sm font-bold border-b-2 border-blue-300 uppercase tracking-widest text-blue-900">DEPO ÇALIŞMASI LİSTESİ</th>
                           </tr>
                           <tr>
                              <th className="p-2 border-r border-blue-200 w-8 text-center font-bold">#</th>
                              <th className="p-2 border-r border-blue-200 w-48 font-bold">Ad Soyad</th>
                              <th className="p-2 border-r border-blue-200 font-bold hidden sm:table-cell">Grup</th>
                              {getWeekDates(selectedWeekStart).map(dateStr => (
                                  <th key={dateStr} className="p-2 border-r border-blue-200 text-center font-bold w-12">{formatDateTR(dateStr)}</th>
                              ))}
                           </tr>
                        </thead>
                        <tbody className="divide-y divide-blue-100">
                           {generatedGrid
                               .filter(row => showOnlyAssignedTasks ? Object.values(row.tasks || {}).includes('Depo') : true)
                               .map((row, idx) => (
                               <tr key={`d-${row.personnel_id}`} className="hover:bg-blue-50/50">
                                   <td className="p-2 border-r border-blue-100 text-center text-blue-600 font-medium">{idx + 1}</td>
                                   <td className="p-2 border-r border-blue-100 font-medium text-gray-800">{row.adSoyad}</td>
                                   <td className="p-2 border-r border-blue-100 text-gray-500 hidden sm:table-cell">{row.department}</td>
                                   {getWeekDates(selectedWeekStart).map(dateStr => (
                                       <td key={`d-${row.personnel_id}-${dateStr}`} className="p-1 border-r border-blue-100 text-center">
                                           {row.shifts[dateStr] ? (
                                               <button 
                                                 onClick={() => handleTaskChange(row.personnel_id, dateStr, row.tasks[dateStr] === 'Depo' ? '' : 'Depo')}
                                                 className={`w-full py-1 rounded transition-colors ${row.tasks[dateStr] === 'Depo' ? 'bg-blue-500 text-white font-bold' : 'bg-gray-100 text-gray-400 hover:bg-blue-200'}`}
                                               >
                                                 {row.tasks[dateStr] === 'Depo' ? 'D' : '-'}
                                               </button>
                                           ) : (
                                               <div className="w-full py-1 bg-gray-50 text-gray-300 rounded">-</div>
                                           )}
                                       </td>
                                   ))}
                               </tr>
                           ))}
                        </tbody>
                     </table>
                  </div>
              </div>

           </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ShiftEngineTab;
