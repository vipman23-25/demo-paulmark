import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function test() {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    console.log("Testing personnel...");
    const r1 = await supabase.from('personnel').select('id, first_name, last_name, department, gender').eq('is_active', true).limit(1);
    if (r1.error) console.error("R1 Error:", r1.error);

    console.log("Testing personnel_movements...");
    const r2 = await supabase.from('personnel_movements').select('personnel_id, start_date, end_date, movement_type').gte('start_date', thirtyDaysAgo).limit(1);
    if (r2.error) console.error("R2 Error:", r2.error);

    console.log("Testing weekly_day_off...");
    const r3 = await supabase.from('weekly_day_off').select('personnel_id, day_of_week').eq('status', 'approved').limit(1);
    if (r3.error) console.error("R3 Error:", r3.error);

    console.log("Testing department_shift_rules...");
    const r4 = await supabase.from('department_shift_rules').select('*').limit(1);
    if (r4.error) console.error("R4 Error:", r4.error);

    console.log("Testing shift_schedules...");
    const r5 = await supabase.from('shift_schedules').select('personnel_id, shift_date, shift_type, task_assignment, week_start_date').gte('shift_date', thirtyDaysAgo).limit(1);
    if (r5.error) console.error("R5 Error:", r5.error);

    console.log("Testing shift_preferences...");
    const r6 = await supabase.from('shift_preferences').select('personnel_id, preference_date, preferred_shift').eq('status', 'approved').limit(1);
    if (r6.error) console.error("R6 Error:", r6.error);

    console.log("Testing system_settings...");
    const r7 = await supabase.from('system_settings').select('setting_key, setting_value').in('setting_key', ['general', 'shift_engine_config']).limit(1);
    if (r7.error) console.error("R7 Error:", r7.error);

    console.log("Testing shift_dependency_rules...");
    const r8 = await supabase.from('shift_dependency_rules').select('*').limit(1);
    if (r8.error) console.error("R8 Error:", r8.error);

    console.log("Done");
}

test();
