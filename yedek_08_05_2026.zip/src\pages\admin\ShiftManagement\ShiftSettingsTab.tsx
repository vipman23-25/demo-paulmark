import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import { Trash2, Eye, EyeOff } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

const DAYS = ['', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];

const TaskConfigPanel = ({ title, desc, config, onUpdate, personnelList, depts, shiftCodes }: any) => {
    const c = config || { count: 0, gender: 'Tümü', departments: [], included_personnel: [], excluded_personnel: [], active_days: [1,2,3,4,5,6,7], valid_shifts: [] };
    const toggleArray = (arr: string[], val: string) => arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val];

    return (
        <div className="p-4 bg-muted/30 rounded-xl border flex flex-col gap-4 shadow-sm">
            <div>
               <p className="font-semibold text-foreground text-sm">{title}</p>
               <p className="text-xs text-muted-foreground mt-1">{desc}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
               <div>
                  <Label className="text-xs mb-1.5 block font-medium">Günlük Çalışacak Kişi Sayısı</Label>
                  <Input type="number" min="0" value={c.count || 0} onChange={e => onUpdate({...c, count: parseInt(e.target.value) || 0})} className="h-8 bg-background" />
               </div>
               <div>
                  <Label className="text-xs mb-1.5 block font-medium">Cinsiyet Kuralı</Label>
                  <Select value={c.gender || 'Tümü'} onValueChange={v => onUpdate({...c, gender: v})}>
                     <SelectTrigger className="h-8 bg-background"><SelectValue /></SelectTrigger>
                     <SelectContent>
                        <SelectItem value="Tümü">Tümü</SelectItem>
                        <SelectItem value="Erkek">Sadece Erkek</SelectItem>
                        <SelectItem value="Kadın">Sadece Kadın</SelectItem>
                     </SelectContent>
                  </Select>
               </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                   <Label className="text-xs font-medium">Geçerli Günler (Seçilmezse Kapalı)</Label>
                   <div className="max-h-24 overflow-y-auto border rounded-md p-2 bg-background flex flex-col gap-1.5">
                      {[1, 2, 3, 4, 5, 6, 7].map((d) => (
                          <label key={`day-${d}`} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-muted/50 p-1 rounded">
                              <input type="checkbox" checked={c.active_days?.includes(d)} onChange={() => onUpdate({...c, active_days: toggleArray(c.active_days || [], d as any)})} className="rounded text-indigo-600" />
                              {DAYS[d]}
                          </label>
                      ))}
                   </div>
                </div>
                <div className="space-y-1.5">
                   <Label className="text-xs font-medium">Geçerli Vardiyalar (Örn: S, A)</Label>
                   <div className="max-h-24 overflow-y-auto border rounded-md p-2 bg-background flex flex-col gap-1.5">
                      {shiftCodes?.map((sc: any) => sc.code && sc.code !== '-' && (
                          <label key={`sc-${sc.code}`} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-muted/50 p-1 rounded">
                              <input type="checkbox" checked={c.valid_shifts?.includes(sc.code)} onChange={() => onUpdate({...c, valid_shifts: toggleArray(c.valid_shifts || [], sc.code)})} className="rounded text-indigo-600" />
                              {sc.code} - {sc.label}
                          </label>
                      ))}
                   </div>
                </div>
            </div>

            <div className="space-y-1.5">
               <Label className="text-xs font-medium">Geçerli Reyonlar (Boşsa Tümü)</Label>
               <div className="max-h-24 overflow-y-auto border rounded-md p-2 bg-background flex flex-col gap-1.5">
                  {depts?.map((d: string) => (
                      <label key={d} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-muted/50 p-1 rounded">
                          <input type="checkbox" checked={c.departments?.includes(d)} onChange={() => onUpdate({...c, departments: toggleArray(c.departments || [], d)})} className="rounded text-indigo-600" />
                          {d}
                      </label>
                  ))}
               </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                   <Label className="text-xs text-green-700 font-bold flex items-center gap-1">Daima Ekle <span className="text-[10px] text-green-600/70 font-normal">(Öncelikli)</span></Label>
                   <div className="max-h-32 overflow-y-auto border rounded-md p-2 bg-background flex flex-col gap-1.5">
                      {personnelList?.map((p: any) => (
                          <label key={`inc-${p.id}`} className={`flex items-center gap-2 text-xs cursor-pointer hover:bg-muted/50 p-1 rounded ${c.excluded_personnel?.includes(p.id) ? 'opacity-50' : ''}`}>
                              <input type="checkbox" checked={c.included_personnel?.includes(p.id)} onChange={() => onUpdate({...c, included_personnel: toggleArray(c.included_personnel || [], p.id)})} disabled={c.excluded_personnel?.includes(p.id)} className="rounded text-green-600" />
                              {p.first_name} {p.last_name}
                          </label>
                      ))}
                   </div>
                </div>
                <div className="space-y-1.5">
                   <Label className="text-xs text-red-700 font-bold flex items-center gap-1">Asla Ekleme <span className="text-[10px] text-red-600/70 font-normal">(Yasaklı)</span></Label>
                   <div className="max-h-32 overflow-y-auto border rounded-md p-2 bg-background flex flex-col gap-1.5">
                      {personnelList?.map((p: any) => (
                          <label key={`exc-${p.id}`} className={`flex items-center gap-2 text-xs cursor-pointer hover:bg-muted/50 p-1 rounded ${c.included_personnel?.includes(p.id) ? 'opacity-50' : ''}`}>
                              <input type="checkbox" checked={c.excluded_personnel?.includes(p.id)} onChange={() => onUpdate({...c, excluded_personnel: toggleArray(c.excluded_personnel || [], p.id)})} disabled={c.included_personnel?.includes(p.id)} className="rounded text-red-600" />
                              {p.first_name} {p.last_name}
                          </label>
                      ))}
                   </div>
                </div>
            </div>
        </div>
    );
};

const ShiftSettingsTab = () => {
  const queryClient = useQueryClient();
  const [genderForm, setGenderForm] = useState({ gender: '', day_of_week: '', warning_message: '' });
  const [depForm, setDepForm] = useState({ personnel_id: '', target_department: '', trigger_absence_count: '1', trigger_shift_type: 'S', action_shift_type: 'A' });


  const { data: shiftCodes, isLoading: loadingCodes } = useQuery({
    queryKey: ['system_settings_shift_codes'],
    queryFn: async () => {
      const { data: generalData, error: generalError } = await supabase.from('system_settings' as any).select('setting_value').eq('setting_key', 'general').maybeSingle();
      if (generalError) throw generalError;
      return generalData?.setting_value?.movementTypes || [];
    }
  });

  const { data: engineConfig, isLoading: loadingConfig } = useQuery({
    queryKey: ['shift_engine_config'],
    queryFn: async () => {
      const { data, error } = await supabase.from('system_settings' as any).select('setting_value').eq('setting_key', 'shift_engine_config').maybeSingle();
      if (error) throw error;
      return data?.setting_value || { blockMultipleAbsence: true };
    }
  });

  const updateEngineConfig = useMutation({
    mutationFn: async (newConfig: any) => {
      const { error } = await supabase.from('system_settings' as any).upsert({
        setting_key: 'shift_engine_config',
        setting_value: newConfig
      }, { onConflict: 'setting_key' });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shift_engine_config'] });
      toast.success('Motor ayarları güncellendi');
    }
  });



  const { data: genderRules, isLoading: loadingGender } = useQuery({
    queryKey: ['shift_gender_rules'],
    queryFn: async () => {
      const { data, error } = await supabase.from('shift_gender_rules').select('*').order('day_of_week');
      if (error) throw error;
      return data;
    }
  });

  const { data: deptRules, isLoading: loadingDept } = useQuery({
    queryKey: ['department_shift_rules'],
    queryFn: async () => {
      const { data, error } = await supabase.from('department_shift_rules').select('*');
      if (error) throw error;
      return data;
    }
  });

  const { data: personnelDepts } = useQuery({
    queryKey: ['distinct_departments'],
    queryFn: async () => {
      const { data, error } = await supabase.from('personnel').select('department');
      if (error) throw error;
      const unq = Array.from(new Set(data.map(d => d.department))).filter(Boolean);
      return unq;
    }
  });

  const { data: personnelList } = useQuery({
    queryKey: ['active_personnel_list'],
    queryFn: async () => {
      const { data, error } = await supabase.from('personnel').select('id, first_name, last_name, department').eq('is_active', true).order('first_name');
      if (error) throw error;
      return data;
    }
  });

  const { data: dependencyRules } = useQuery({
    queryKey: ['shift_dependency_rules'],
    queryFn: async () => {
      const { data, error } = await supabase.from('shift_dependency_rules').select(`
        *,
        personnel:personnel_id(first_name, last_name)
      `).order('created_at', { ascending: false });
      // Hata fırlatmadan boş dönelim ki tablo yoksa crash olmasın
      if (error) return [];
      return data;
    }
  });

  const addGenderRule = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from('shift_gender_rules').insert({
        gender: genderForm.gender,
        day_of_week: parseInt(genderForm.day_of_week),
        warning_message: genderForm.warning_message
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shift_gender_rules'] });
      setGenderForm({ gender: '', day_of_week: '', warning_message: '' });
      toast.success('Kural eklendi');
    }
  });

  const deleteGenderRule = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('shift_gender_rules').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shift_gender_rules'] });
      toast.success('Kural silindi');
    }
  });

  const addDependencyRule = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from('shift_dependency_rules').insert({
        personnel_id: depForm.personnel_id,
        target_department: depForm.target_department,
        trigger_absence_count: parseInt(depForm.trigger_absence_count),
        trigger_shift_type: depForm.trigger_shift_type,
        action_shift_type: depForm.action_shift_type
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shift_dependency_rules'] });
      setDepForm({ personnel_id: '', target_department: '', trigger_absence_count: '1', trigger_shift_type: 'S', action_shift_type: 'A' });
      toast.success('Destek kuralı eklendi');
    }
  });

  const deleteDependencyRule = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('shift_dependency_rules').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shift_dependency_rules'] });
      toast.success('Destek kuralı silindi');
    }
  });

  const upsertDeptRule = useMutation({
    mutationFn: async ({ dept, mCount, eCount }: { dept: string, mCount: string, eCount: string }) => {
      // Basic upsert fallback logic if constraints fail
      const { data: existing } = await supabase.from('department_shift_rules').select('*').eq('department_name', dept).single();
      let error;
      if (existing) {
         const res = await supabase.from('department_shift_rules').update({ override_morning_count: mCount ? parseInt(mCount) : null, override_evening_count: eCount ? parseInt(eCount) : null }).eq('id', existing.id);
         error = res.error;
      } else {
         const res = await supabase.from('department_shift_rules').insert({ department_name: dept, override_morning_count: mCount ? parseInt(mCount) : null, override_evening_count: eCount ? parseInt(eCount) : null });
         error = res.error;
      }
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['department_shift_rules'] });
      toast.success('Reyon kuralı güncellendi');
    }
  });

  const handleAddGenderRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!genderForm.gender || !genderForm.day_of_week) return toast.error('Cinsiyet ve gün seçiniz');
    addGenderRule.mutate();
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Vardiya Motoru Kuralları</CardTitle>
          <CardDescription>Otomatik dağıtım esnasında çalışacak zorunlu kuralları açıp kapatabilirsiniz.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg border">
              <div>
                <p className="font-medium text-foreground">Aynı Reyonda Birden Fazla İzin/Rapor Engellemesi</p>
                <p className="text-xs text-muted-foreground mt-0.5">Aynı gün içerisinde bir reyonda birden fazla personel devamsız ise motor hata vererek tabloyu oluşturmayı durdurur.</p>
              </div>
              <Switch 
                checked={engineConfig?.blockMultipleAbsence ?? true}
                onCheckedChange={(v) => updateEngineConfig.mutate({ ...engineConfig, blockMultipleAbsence: v })}
                disabled={updateEngineConfig.isPending || loadingConfig}
              />
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <TaskConfigPanel 
                  title="Depo Görevi Atama Kuralları" 
                  desc="Akşam (A) vardiyasındakilerden otomatik olarak depo görevi atanacak kişileri belirleyin."
                  config={engineConfig?.depo_config}
                  onUpdate={(newCfg: any) => updateEngineConfig.mutate({ ...engineConfig, depo_config: newCfg })}
                  personnelList={personnelList}
                  depts={personnelDepts}
                  shiftCodes={shiftCodes}
              />
              <TaskConfigPanel 
                  title="Mutfak Görevi Atama Kuralları" 
                  desc="Sabah (S) vardiyasındakilerden otomatik olarak mutfak görevi atanacak kişileri belirleyin."
                  config={engineConfig?.mutfak_config}
                  onUpdate={(newCfg: any) => updateEngineConfig.mutate({ ...engineConfig, mutfak_config: newCfg })}
                  personnelList={personnelList}
                  depts={personnelDepts}
                  shiftCodes={shiftCodes}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Cinsiyete Göre İzin Günü Kısıtlaması</CardTitle>
          <CardDescription>Belirli bir günde Erkek/Kadın personellerin izin kullanmasını engelleyebilirsiniz.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form onSubmit={handleAddGenderRule} className="grid grid-cols-1 sm:grid-cols-2 gap-4 border p-4 rounded-lg bg-muted/10">
            <div className="space-y-2">
              <Label>Cinsiyet</Label>
              <Select value={genderForm.gender} onValueChange={(v) => setGenderForm({...genderForm, gender: v})}>
                <SelectTrigger><SelectValue placeholder="Seçiniz"/></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Erkek">Erkek</SelectItem>
                  <SelectItem value="Kadın">Kadın</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Yasaklı Gün</Label>
              <Select value={genderForm.day_of_week} onValueChange={(v) => setGenderForm({...genderForm, day_of_week: v})}>
                <SelectTrigger><SelectValue placeholder="Gün Seçiniz"/></SelectTrigger>
                <SelectContent>
                  {DAYS.map((d, i) => d ? <SelectItem key={i} value={i.toString()}>{d}</SelectItem> : null)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label>Uyarı Mesajı (Personele görünecek)</Label>
              <Input placeholder="Örn: Hafta sonları yalnızca kadın personeller..." value={genderForm.warning_message} onChange={e => setGenderForm({...genderForm, warning_message: e.target.value})} />
            </div>
            <div className="sm:col-span-2 flex justify-end">
              <Button type="submit" disabled={addGenderRule.isPending}>Kuralı Ekle</Button>
            </div>
          </form>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cinsiyet</TableHead>
                <TableHead>Gün</TableHead>
                <TableHead>Uyarı Mesajı</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {genderRules?.map((r: any) => (
                <TableRow key={r.id}>
                  <TableCell>{r.gender}</TableCell>
                  <TableCell>{DAYS[r.day_of_week]}</TableCell>
                  <TableCell className="text-muted-foreground text-xs">{r.warning_message}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => deleteGenderRule.mutate(r.id)}><Trash2 className="w-4 h-4 text-red-500"/></Button>
                  </TableCell>
                </TableRow>
              ))}
              {!genderRules?.length && (
                <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground">Kayıtlı kural yok.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Dinamik Personel Destek ve Eşleşme Kuralları</CardTitle>
          <CardDescription>Belirli bir personelin, başka bir reyondaki eksikliğe veya vardiya durumuna göre otomatik vardiya (S/A) almasını sağlayabilirsiniz.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form onSubmit={(e) => { e.preventDefault(); if (!depForm.personnel_id || !depForm.target_department) return toast.error('Lütfen personel ve reyon seçiniz'); addDependencyRule.mutate(); }} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 border p-4 rounded-lg bg-indigo-50/50 dark:bg-indigo-900/10 border-indigo-100 dark:border-indigo-800/30">
            <div className="space-y-2">
              <Label>Destek Verecek Personel</Label>
              <Select value={depForm.personnel_id} onValueChange={(v) => setDepForm({...depForm, personnel_id: v})}>
                <SelectTrigger><SelectValue placeholder="Seçiniz"/></SelectTrigger>
                <SelectContent>
                  {personnelList?.map((p: any) => (
                    <SelectItem key={p.id} value={p.id}>{p.first_name} {p.last_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Hedef Reyon</Label>
              <Select value={depForm.target_department} onValueChange={(v) => setDepForm({...depForm, target_department: v})}>
                <SelectTrigger><SelectValue placeholder="Seçiniz"/></SelectTrigger>
                <SelectContent>
                  {personnelDepts?.map((d: any) => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Kaç Kişi İzinliyse?</Label>
              <Input type="number" min="1" value={depForm.trigger_absence_count} onChange={e => setDepForm({...depForm, trigger_absence_count: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>Kalanlar Hangi Vardiyadaysa?</Label>
              <Select value={depForm.trigger_shift_type} onValueChange={(v) => setDepForm({...depForm, trigger_shift_type: v})}>
                <SelectTrigger><SelectValue placeholder="Örn: S"/></SelectTrigger>
                <SelectContent>
                  {shiftCodes?.map((c: any) => (
                      <SelectItem key={c.code || '-'} value={c.code || '-'}>{c.code || 'Tümü'}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Destek Vardiyası (Geçeceği)</Label>
              <Select value={depForm.action_shift_type} onValueChange={(v) => setDepForm({...depForm, action_shift_type: v})}>
                <SelectTrigger><SelectValue placeholder="Örn: A"/></SelectTrigger>
                <SelectContent>
                  {shiftCodes?.map((c: any) => (
                      <SelectItem key={c.code || '-'} value={c.code || '-'}>{c.code || 'Tümü'}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-5 flex justify-end">
              <Button type="submit" disabled={addDependencyRule.isPending} className="bg-indigo-600 hover:bg-indigo-700 text-white">Destek Kuralı Ekle</Button>
            </div>
          </form>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Destek Personeli</TableHead>
                <TableHead>Hedef Reyon</TableHead>
                <TableHead>Tetiklenme Şartı</TableHead>
                <TableHead>Atanacak Vardiya</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dependencyRules?.map((r: any) => (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.personnel?.first_name} {r.personnel?.last_name}</TableCell>
                  <TableCell>{r.target_department}</TableCell>
                  <TableCell className="text-muted-foreground text-xs">
                    Hedefte en az {r.trigger_absence_count} kişi izinli/yok ve diğerleri {r.trigger_shift_type} vardiyasında ise
                  </TableCell>
                  <TableCell>
                    <span className="font-bold text-indigo-600 px-2 py-1 bg-indigo-50 rounded-md border">{r.action_shift_type}</span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => deleteDependencyRule.mutate(r.id)}><Trash2 className="w-4 h-4 text-red-500"/></Button>
                  </TableCell>
                </TableRow>
              ))}
              {!dependencyRules?.length && (
                <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6">Kayıtlı destek/eşleşme kuralı yok.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Reyon Vardiya Oranları (Sabah/Akşam)</CardTitle>
          <CardDescription>Motorun otomatik oluşturacağı Sabah/Akşam kişi sayısını manuel kısıtlayabilirsiniz. (Boş bırakılırsa sistem mevcut kişi sayısına göre orantılar)</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Reyon</TableHead>
                <TableHead>Sabahçı Sy.</TableHead>
                <TableHead>Akşamcı Sy.</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {personnelDepts?.map((dept: any) => {
                const rule = deptRules?.find((r: any) => r.department_name === dept) || {};
                return (
                  <RuleRow key={dept} dept={dept} rule={rule} onSave={(m, e) => upsertDeptRule.mutate({ dept, mCount: m, eCount: e })} />
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Vardiya Hücre Seçenekleri</CardTitle>
          <CardDescription>
            Vardiya seçenekleri artık doğrudan <strong>Sistem Ayarları &gt; Personel Hareket Türleri</strong> menüsünden yönetilmektedir. <br/>
            Ekleme ve çıkarma işlemlerini oradan yapabilirsiniz. Aşağıda şu an aktif olan seçenekleri görebilirsiniz.
          </CardDescription>
        </CardHeader>
        <CardContent>
           <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {shiftCodes?.map((c: any) => (
                  <div key={c.code} className="flex items-center justify-between border rounded p-2 bg-primary/5 border-primary/20">
                      <div className="overflow-hidden">
                         <p className="font-bold text-sm truncate" title={c.code}>{c.code}</p>
                         <p className="text-xs text-muted-foreground truncate" title={c.label}>{c.label}</p>
                      </div>
                  </div>
              ))}
              {!shiftCodes?.length && (
                 <div className="col-span-full text-center text-muted-foreground py-4">Kayıtlı hareket türü bulunmuyor.</div>
              )}
           </div>
        </CardContent>
      </Card>
    </div>
  );
};

const RuleRow = ({ dept, rule, onSave }: any) => {
  const [mCount, setMCount] = useState(rule.override_morning_count || '');
  const [eCount, setECount] = useState(rule.override_evening_count || '');

  return (
    <TableRow>
      <TableCell className="font-semibold">{dept}</TableCell>
      <TableCell><Input type="number" min="0" placeholder="Oto" className="w-20" value={mCount} onChange={e => setMCount(e.target.value)} /></TableCell>
      <TableCell><Input type="number" min="0" placeholder="Oto" className="w-20" value={eCount} onChange={e => setECount(e.target.value)} /></TableCell>
      <TableCell className="text-right">
        <Button variant="outline" size="sm" onClick={() => onSave(mCount, eCount)}>Kaydet</Button>
      </TableCell>
    </TableRow>
  );
};

export default ShiftSettingsTab;
